// IObserver.java
public interface IObserver<T> {
    void update(T data);
}

// StockPriceChange.java
public class StockPriceChange {
    public final String ticker;
    public final double price;
    public final double change;

    public StockPriceChange(String ticker, double price, double change) {
        this.ticker = ticker;
        this.price = price;
        this.change = change;
    }
}

// StockFeed.java
import java.util.List;
import java.util.ArrayList;

public class StockFeed {
    private final List<IObserver<StockPriceChange>> observers = new ArrayList<>();

    public void attach(IObserver<StockPriceChange> o) {
        observers.add(o);
    }

    public void detach(IObserver<StockPriceChange> o) {
        observers.remove(o);
    }

    public void publish(StockPriceChange data) {
        for (var o : observers) o.update(data);
    }
}