// IDiscountStrategy.java
public interface IDiscountStrategy {
    double apply(double subtotal, CustomerContext ctx);
}

// SeasonalDiscount.java
public class SeasonalDiscount implements IDiscountStrategy {
    @Override
    public double apply(double subtotal, CustomerContext ctx) {
        if (ctx.isSeasonal()) return subtotal * 0.9; // 10% off
        return subtotal;
    }
}

// LoyaltyDiscount.java
public class LoyaltyDiscount implements IDiscountStrategy {
    @Override
    public double apply(double subtotal, CustomerContext ctx) {
        if (ctx.getLoyaltyPoints() > 1000) return subtotal * 0.85;
        return subtotal;
    }
}