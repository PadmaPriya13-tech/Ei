// Product parts  
class Pizza { String size; List<String> toppings = new ArrayList<>(); }  
class Drink { String type; }  

class Order {  
    public final List<Pizza> pizzas = new ArrayList<>();  
    public final List<Drink> drinks = new ArrayList<>();  
    public double total = 0.0;  

    void addPizza(Pizza p) { pizzas.add(p); }  
    void addDrink(Drink d) { drinks.add(d); }  
}  

// Builder  
class OrderBuilder {  
    private final Order order = new Order();  

    public OrderBuilder addPizza(Pizza p) { order.addPizza(p); recalc(); return this; }  
    public OrderBuilder