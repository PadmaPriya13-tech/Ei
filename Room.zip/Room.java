// Room.java
import java.time.LocalDateTime;

public class Room {
    private final int id;
    private final String name;
    private int maxCapacity = 10;
    private Booking currentBooking;
    private final OccupancyTracker occupancy;
    private final Lights lights;
    private final AC ac;

    public Room(int id, String name) {
        this.id = id;
        this.name = name;
        this.occupancy = new OccupancyTracker(this);
        this.lights = new Lights();
        this.ac = new AC();
        occupancy.addObserver(lights);
        occupancy.addObserver(ac);
    }

    public String getName() { return name; }

    public int getId() { return id; }

    public void setMaxCapacity(int cap) {
        if (cap <= 0) throw new IllegalArgumentException("Capacity must be positive");
        this.maxCapacity = cap;
    }

    public int getMaxCapacity() { return maxCapacity; }

    public boolean isOccupied() {
        return occupancy.isOccupied();
    }

    public boolean book(Booking b) {
        if (currentBooking != null && currentBooking.isActive()) {
            return false;
        }
        currentBooking = b;
        return true;
    }

    public Booking getCurrentBooking() { return currentBooking; }

    public void cancelBooking() {
        currentBooking = null;
        // If needed, notify
    }

    public void addOccupant(int count) {
        occupancy.reportOccupancy(count);
    }

    public void removeOccupant(int count) {
        occupancy.reportOccupancy(-count);
    }

    // Internal helpers used by observers
    public void onOccupancyChanged() {
        // No-op here; observers are notified via OccupancyTracker
    }
}