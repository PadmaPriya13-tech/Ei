// Booking.java
import java.time.LocalDateTime;

public class Booking {
    private final LocalDateTime start;
    private final int durationMinutes;
    private boolean active;

    public Booking(LocalDateTime start, int durationMinutes) {
        this.start = start;
        this.durationMinutes = durationMinutes;
        this.active = true;
    }

    public boolean overlaps(Booking other) {
        if (other == null) return false;
        LocalDateTime s1 = this.start;
        LocalDateTime e1 = this.start.plusMinutes(this.durationMinutes);
        LocalDateTime s2 = other.start;
        LocalDateTime e2 = other.start.plusMinutes(other.durationMinutes);
        return s1.isBefore(e2) && s2.isBefore(e1);
    }

    public boolean isActive() { return active; }

    public void cancel() { active = false; }

    // getters
    public LocalDateTime getStart() { return start; }
    public int getDurationMinutes() { return durationMinutes; }
}