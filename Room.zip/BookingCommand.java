// BookingCommand.java
import java.time.LocalDateTime;

public class BookingCommand implements Command {
    private final int roomId;
    private final LocalDateTime start;
    private final int duration;
    private final OfficeConfig config = OfficeConfig.getInstance();

    public BookingCommand(int roomId, LocalDateTime start, int duration) {
        this.roomId = roomId;
        this.start = start;
        this.duration = duration;
    }

    @Override
    public void execute() {
        Room room = config.getRoom(roomId);
        if (room == null) {
            System.out.println("Invalid room number. Please enter a valid room number.");
            return;
        }
        Booking b = new Booking(start, duration);
        if (room.getCurrentBooking() != null && room.getCurrentBooking().isActive()) {
            System.out.println("Room " + roomId + " is already booked during this time. Cannot book.");
            return;
        }
        room.book(b);
        System.out.println("Room " + roomId + " booked from " + start + " for " + duration + " minutes.");
    }

    @Override
    public String description() { return "Block room " + roomId + " " + start + " " + duration; }
}