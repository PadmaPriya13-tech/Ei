// AddOccupantCommand.java
public class AddOccupantCommand implements Command {
    private final int roomId;
    private final int count;
    private final OfficeConfig config = OfficeConfig.getInstance();

    public AddOccupantCommand(int roomId, int count) {
        this.roomId = roomId;
        this.count = count;
    }

    @Override
    public void execute() {
        Room room = config.getRoom(roomId);
        if (room == null) {
            System.out.println("Room " + roomId + " does not exist.");
            return;
        }
        if (count <= 0) {
            System.out.println("Invalid occupant count. Please enter a positive number.");
            return;
        }
        room.addOccupant(count);
        String status = room.isOccupied() ? "occupied" : "unoccupied";
        System.out.println("Room " + roomId + " is now " + status + " with occupancy " +
                room.isOccupied() + " (occupant delta: " + count + ").");
    }

    @Override
    public String description() { return "Add occupant " + roomId + " " + count; }
}