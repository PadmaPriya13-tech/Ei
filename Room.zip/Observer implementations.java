// Observer implementations
public class Lights implements Observer {
    private boolean on = false;
    @Override
    public void update(Room room) {
        // Simple heuristic: if room occupied -> lights on, else off
        boolean shouldBeOn = room.isOccupied();
        if (shouldBeOn != on) {
            on = shouldBeOn;
            System.out.println("Lights in " + room.getName() + " turned " + (on ? "ON" : "OFF"));
        }
    }
}

public class AC implements Observer {
    private boolean on = false;
    @Override
    public void update(Room room) {
        boolean shouldBeOn = room.isOccupied();
        if (shouldBeOn != on) {
            on = shouldBeOn;
            System.out.println("AC in " + room.getName() + " turned " + (on ? "ON" : "OFF"));
        }
    }
}