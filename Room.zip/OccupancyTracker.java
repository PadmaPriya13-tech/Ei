// OccupancyTracker.java
import java.util.ArrayList;
import java.util.List;

public class OccupancyTracker {
    private final Room room;
    private int occupantCount = 0;
    private final List<Observer> observers = new ArrayList<>();
    private boolean occupiedCache = false;

    public OccupancyTracker(Room room) {
        this.room = room;
    }

    public void addObserver(Observer o) { observers.add(o); }

    public boolean isOccupied() { return occupiedCache; }

    public void reportOccupancy(int delta) {
        int newCount = Math.max(0, occupantCount + delta);
        boolean previouslyOccupied = occupantCount >= 2;
        occupantCount = newCount;
        boolean currentlyOccupied = occupantCount >= 2;
        if (currentlyOccupied != previouslyOccupied) {
            occupiedCache = currentlyOccupied;
            notifyObservers();
        }
    }

    private void notifyObservers() {
        for (Observer o : observers) {
            o.update(room);
        }
    }

    public int getOccupantCount() { return occupantCount; }
}