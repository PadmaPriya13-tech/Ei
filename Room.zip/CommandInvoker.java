// CommandInvoker.java
import java.util.ArrayList;
import java.util.List;

public class CommandInvoker {
    private final List<Command> history = new ArrayList<>();

    public void submit(Command c) {
        history.add(c);
        c.execute();
    }

    public List<Command> getHistory() { return List.copyOf(history); }
}