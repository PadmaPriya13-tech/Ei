// Command interface and sample commands
public interface Command {
    void execute();
    String description();
}