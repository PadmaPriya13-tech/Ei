// CancelBookingCommand.java
public class CancelBookingCommand implements Command {
    private final int roomId;
    private final OfficeConfig config = OfficeConfig.getInstance();

    public CancelBookingCommand(int roomId) { this.roomId = roomId; }

    @Override
    public void execute() {
        Room room = config.getRoom(roomId);
        if (room == null) {
            System.out.println("Invalid room number. Please enter a valid room number.");
            return;
        }
        if (room.getCurrentBooking() == null || !room.getCurrentBooking().isActive()) {
            System.out.println("Room " + roomId + " is not booked. Cannot cancel booking.");
            return;
        }
        room.cancelBooking();
        System.out.println("Booking for Room " + roomId + " cancelled successfully.");
    }

    @Override
    public String description() { return "Cancel room " + roomId; }
}