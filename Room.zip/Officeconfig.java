officeconfig:

// OfficeConfig.java
import java.util.*;

public class OfficeConfig {
    private static OfficeConfig instance;
    private int roomCount;
    private List<Room> rooms = new ArrayList<>();
    private Map<Integer, Room> roomMap = new HashMap<>();

    private OfficeConfig() {}

    public static synchronized OfficeConfig getInstance() {
        if (instance == null) {
            instance = new OfficeConfig();
        }
        return instance;
    }

    public void configure(int count) {
        this.roomCount = count;
        rooms.clear();
        roomMap.clear();
        for (int i = 1; i <= count; i++) {
            Room r = new Room(i, "Room " + i);
            rooms.add(r);
            roomMap.put(i, r);
        }
        System.out.println("Office configured with " + count + " meeting rooms: " +
                rooms.stream().map(r -> r.getName()).toList());
    }

    public Room getRoom(int id) {
        return roomMap.get(id);
    }

    public List<Room> getAllRooms() {
        return Collections.unmodifiableList(rooms);
    }
}