ConcreteStrategyB.java
package com.example.patterns.behavioral.impl;

import com.example.patterns.behavioral.interface_.Strategy;

public class ConcreteStrategyB implements Strategy {
    @Override
    public double execute(double input) {
        // Alternative: add a fixed amount
        return input + 15;
    }
}