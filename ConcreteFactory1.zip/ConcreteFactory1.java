ConcreteFactory1.java
package com.example.patterns.creational.factory;

import com.example.patterns.creational.product.Product;
import com.example.patterns.creational.product.ProductA;

public class ConcreteFactory1 extends Factory {
    @Override
    public Product createProduct() {
        return new ProductA();
    }
}