factory.java
package com.example.patterns.creational.factory;

import com.example.patterns.creational.product.Product;

public abstract class Factory {
    public abstract Product createProduct();

    public void useProduct() {
        Product p = createProduct();
        p.operation();
    }
}