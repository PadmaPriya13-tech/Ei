ProductB.java
package com.example.patterns.creational.product;

public class ProductB implements Product {
    @Override
    public void operation() {
        System.out.println("ProductB: operation");
    }
}