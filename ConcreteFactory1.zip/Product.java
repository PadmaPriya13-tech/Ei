Product.java
package com.example.patterns.creational.product;

public interface Product {
    void operation();
}