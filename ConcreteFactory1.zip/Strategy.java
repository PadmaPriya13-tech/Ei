// src/main/java/com/example/patterns/behavioral/interface/Strategy.java
package com.example.patterns.behavioral.interface_;

public interface Strategy {
    double execute(double input);
}