StrategyPatternDemo.java
package com.example.patterns.behavioral;

import com.example.patterns.behavioral.impl.ConcreteStrategyA;
import com.example.patterns.behavioral.impl.ConcreteStrategyB;
import com.example.patterns.behavioral.interface_.Strategy;

import java.util.Scanner;
import java.util.logging.Logger;

public class StrategyPatternDemo {
    private static final Logger logger = Logger.getLogger(StrategyPatternDemo.class.getName());

    public static void runDemo() {
        Scanner sc = new Scanner(System.in);
        try {
            System.out.println("Strategy Pattern Demo:");
            Strategy s1 = new ConcreteStrategyA();
            Strategy s2 = new ConcreteStrategyB();
            double input = 100.0;

            System.out.println("Using Strategy A: " + s1.execute(input));
            System.out.println("Using Strategy B: " + s2.execute(input));

            logger.info("Strategy demo executed.");
        } finally {
            sc.close();
        }
    }
}