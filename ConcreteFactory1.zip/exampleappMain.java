// src/main/java/com/example/app/Main.java
package com.example.app;

import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.example.patterns.behavioral.StrategyPatternDemo;
import com.example.patterns.behavioral.ObserverPatternDemo;
import com.example.patterns.creational.FactoryPatternDemo;
import com.example.patterns.creational.AbstractFactoryDemo;
import com.example.patterns.structural.AdapterPatternDemo;
import com.example.patterns.structural.DecoratorPatternDemo;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        // Basic input-driven runner. The real long-running behavior can be extended via external triggers.
        try (Scanner scanner = new Scanner(System.in)) {
            System.out.println("Design Patterns Demo Runner");
            System.out.println("Choose a demonstration to run:");
            System.out.println("1 - Behavioral: Strategy");
            System.out.println("2 - Behavioral: Observer");
            System.out.println("3 - Creational: Factory Method");
            System.out.println("4 - Creational: Abstract Factory");
            System.out.println("5 - Structural: Adapter");
            System.out.println("6 - Structural: Decorator");
            System.out.print("Enter choice (1-6) or 'q' to quit: ");

            while (true) {
                String line = scanner.nextLine();
                line = line == null ? "" : line.trim();
                if (line.equalsIgnoreCase("q")) {
                    System.out.println("Exiting. Goodbye!");
                    break;
                }

                switch (line) {
                    case "1":
                        StrategyPatternDemo.runDemo();
                        break;
                    case "2":
                        ObserverPatternDemo.runDemo();
                        break;
                    case "3":
                        FactoryPatternDemo.runDemo();
                        break;
                    case "4":
                        AbstractFactoryDemo.runDemo();
                        break;
                    case "5":
                        AdapterPatternDemo.runDemo();
                        break;
                    case "6":
                        DecoratorPatternDemo.runDemo();
                        break;
                    default:
                        System.out.println("Invalid choice. Please select 1-6 or q to quit.");
                }

                System.out.print("\nSelect next demo (1-6) or 'q' to quit: ");
            }
        } catch (Exception ex) {
            logger.log(Level.SEVERE, "Unhandled exception in main loop", ex);
        }
    }
}