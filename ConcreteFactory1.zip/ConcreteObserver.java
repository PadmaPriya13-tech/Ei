ConcreteObserver.java
package com.example.patterns.behavioral.impl;

public class ConcreteObserver implements Observer {
    private final String name;

    public ConcreteObserver(String name) { this.name = name; }

    @Override
    public void update(String message) {
        System.out.println("Observer " + name + " received: " + message);
    }
}