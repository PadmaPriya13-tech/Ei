Observer.java
package com.example.patterns.behavioral.impl;

public interface Observer {
    void update(String message);
}