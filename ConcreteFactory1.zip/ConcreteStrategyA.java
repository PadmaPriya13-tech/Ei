ConcreteStrategyA.java
package com.example.patterns.behavioral.impl;

import com.example.patterns.behavioral.interface_.Strategy;

public class ConcreteStrategyA implements Strategy {
    @Override
    public double execute(double input) {
        // Simple example: multiply
        return input * 0.8;
    }
}