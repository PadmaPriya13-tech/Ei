ObserverPatternDemo.java
package com.example.patterns.behavioral;

import com.example.patterns.behavioral.impl.ConcreteObserver;
import com.example.patterns.behavioral.impl.Subject;

public class ObserverPatternDemo {
    public static void runDemo() {
        Subject subject = new Subject();
        ConcreteObserver obs1 = new ConcreteObserver("A");
        ConcreteObserver obs2 = new ConcreteObserver("B");
        subject.attach(obs1);
        subject.attach(obs2);

        subject.notifyObservers("Event 1 occurred");
        subject.detach(obs1);
        subject.notifyObservers("Event 2 occurred");
    }
}