ConcreteFactory2.java
package com.example.patterns.creational.factory;

import com.example.patterns.creational.product.Product;
import com.example.patterns.creational.product.ProductB;

public class ConcreteFactory2 extends Factory {
    @Override
    public Product createProduct() {
        return new ProductB();
    }
}